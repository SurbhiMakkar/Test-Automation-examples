package com.qa.resources;


public class ParseStudent {
	public static void main(String[] args) {
		
		
	}
}
