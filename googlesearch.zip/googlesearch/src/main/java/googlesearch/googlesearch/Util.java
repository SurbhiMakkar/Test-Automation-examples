/**
 * 
 */
package googlesearch.googlesearch;

/**
 * Declare some common parameters/constants for scripts
 * You can change them to adapt your environment
 *
 * @author smakkar
 *
 */
public class Util {
	
	public static String DRIVER_PATH = "C:\\Drivers\\ChromeDriver\\chromedriver_87\\";
	
	// Setting Base URL //
	public static final String BASE_URL = "https://www.google.com/";
	
	//	search key text
	public static final String SEARCH_KEY = "ducks";

}
