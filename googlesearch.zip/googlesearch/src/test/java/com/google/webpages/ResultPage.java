/**
 * 
 */
package com.google.webpages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import googlesearch.googlesearch.Util;

/**
 * @author smakkar
 *
 */
public class ResultPage {

	private WebDriver _driver;

	// find Search Text Box
	@FindBy(name = "q")
	private WebElement searchGoogleText;
	
//	// find Search Text Box
//	@FindBy(partialLinkText = Util.SEARCH_KEY)
//	private List<WebElement> resultLinks;

	// Constructor
	public ResultPage(WebDriver driver) {
		this._driver = driver;
		// Initialize Elements
		PageFactory.initElements(_driver, this);
	}
	
	/**
	 * @return current text value entered in search text box.
	 */
	public String getSearchGoogleText() {
		System.out.println("in getSearchGoogleText");
		String searchText = "";
		if (searchText != null) {
			searchText = searchGoogleText.getAttribute("value");
		}
		return searchText;
	}
	
//	public List<String> getResults(){
//		System.out.println("in getResults");
//		List<String> results = new ArrayList<String>();
//		if(resultLinks != null && !resultLinks.isEmpty()) {
//			System.out.println("Results.size : "+results.size());
//			for (Iterator<WebElement> iterator = resultLinks.iterator(); iterator.hasNext();) {
//				WebElement linkUrl = (WebElement) iterator.next();
//				results.add(linkUrl.getText());
//			}
//		}
//		
//		return results;
//	}
}
