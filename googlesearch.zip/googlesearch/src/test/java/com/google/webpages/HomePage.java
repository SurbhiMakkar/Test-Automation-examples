/**
 * 
 */
package com.google.webpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * @author smakkar
 *
 */
public class HomePage {

	private WebDriver _driver;

	// Page URL
//	private static String PAGE_URL = "https://www.google.com/";

	// Locators

	// find Search Text Box
	@FindBy(name = "q")
	private WebElement searchGoogleText;

	// find Search Button 1``
	@FindBy(name = "btnK")
	private WebElement searchGoogleButton;

	// Constructor
	public HomePage(WebDriver driver) {
		this._driver = driver;
//		_driver.get(PAGE_URL);
		// Initialize Elements
		PageFactory.initElements(_driver, this);
	}

	/**
	 * Set the search text in the search text box.
	 * 
	 * @param searchText text to be searched.
	 */
	public void setGoogleSearchText(String searchText) {
		searchGoogleText.sendKeys(searchText);
	}
	
	/**
	 * @return current text value entered in search text box.
	 */
	public String getSearchGoogleText() {
		String searchText = "";
		if (searchGoogleText != null) {
			searchText = searchGoogleText.getAttribute("value");
		}
		return searchText;
	}

	/**
	 * Click on Search button to submit "search text".
	 */
	public void searchClick() {
		searchGoogleButton.click();
	}

}
