/**
 * 
 */
package com.google.tests;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.webpages.ResultPage;

import googlesearch.googlesearch.Util;

/**
 * @author smakkar
 *
 */
public class ResultPageTest extends TestBase {
	
	private ResultPage resultPage = new ResultPage(driver);

	@Test(priority = 1)
	public void verifySearchedText() {
		System.out.println("in verifySearchedText");
		String searchText = resultPage.getSearchGoogleText();
		Assert.assertTrue(searchText.equalsIgnoreCase(Util.SEARCH_KEY));
	}
	
	@Test(priority = 2)
	public void verifySearchedLinks() {
System.out.println("in verifySearchedLinks");
		List<String> results = resultPage.getResults();
		System.out.println("result size : "+results.size());
		for (int i = 0; i < 5; i++) {
			String linkText = results.get(i);
			assertTrue(linkText.equalsIgnoreCase(Util.SEARCH_KEY));
		}
	}
}
