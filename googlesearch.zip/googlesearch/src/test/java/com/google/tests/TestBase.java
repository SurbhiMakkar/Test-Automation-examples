/**
 * 
 */
package com.google.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import googlesearch.googlesearch.Util;

/**
 * @author smakkar
 *
 */
public class TestBase {

	
    public static WebDriver driver;
    
   

    
    @BeforeSuite
    public  void setBaseUrl() {
    	System.out.println("Launching google chrome with new profile..");
		System.setProperty("webdriver.chrome.driver", Util.DRIVER_PATH
				+ "chromedriver.exe");
		System.out.println("Chrome Driver Path..." + System.getProperty("webdriver.chrome.driver"));
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        System.out.println("Opened window");
        driver.get(Util.BASE_URL);
    }
    
    @AfterSuite
    public void afterSuite() {
        if(null != driver) {
            driver.close();
            driver.quit();
        }
    }

    
}
