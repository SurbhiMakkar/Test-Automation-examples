/**
 * 
 */
package com.google.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.webpages.HomePage;

import googlesearch.googlesearch.Util;

/**
 * @author smakkar
 *
 */
public class HomePageTest extends TestBase {


	@Test
    public void searchGoogle() {
		System.out.println("In HOmePage Test - search Google method");
        HomePage homePage = new HomePage(driver);
        homePage.setGoogleSearchText(Util.SEARCH_KEY);
        
        String searchText = homePage.getSearchGoogleText();
        System.out.println("SearchText : "+searchText);
        Assert.assertTrue(searchText.equalsIgnoreCase(Util.SEARCH_KEY));
        homePage.searchClick();
    }
}
